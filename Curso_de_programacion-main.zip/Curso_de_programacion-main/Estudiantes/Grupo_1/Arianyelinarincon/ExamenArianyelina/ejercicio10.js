const edad=19;
const tieneEntrada=false;

if (edad >=18 && tieneEntrada) {
    console.log("acceso concedido");
} else {
    console.log("acceso denegado");
}