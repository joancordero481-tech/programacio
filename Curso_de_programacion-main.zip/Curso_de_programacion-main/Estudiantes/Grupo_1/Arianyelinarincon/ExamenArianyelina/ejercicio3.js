let edadUsuario = 20;
if (edadUsuario>=20){
    console.log("puedes obtener tu licencia de conducir")
}else {
    console.log("Aun no tienes la edad para tener una licencia")
}