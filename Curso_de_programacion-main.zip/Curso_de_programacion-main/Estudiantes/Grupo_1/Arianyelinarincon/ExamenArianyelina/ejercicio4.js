let colorSemaforo = "amarillo";
 if(colorSemaforo==="verde") {
    console.log("puede avanzar")
 } else if (colorSemaforo==="amarillo"){
    console.log("Reduzca la velocidad, precaución")
 } else if (colorSemaforo==="rojo") {
    console.log("Debe detenerse.")
 }  else {
    console.log("Color no válido.")
 }