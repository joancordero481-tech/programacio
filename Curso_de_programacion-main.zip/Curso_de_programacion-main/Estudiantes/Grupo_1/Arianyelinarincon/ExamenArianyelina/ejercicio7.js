let cuenta=10;
while (cuenta>=1){
    console.log(cuenta);
    cuenta--;
}
console.log("¡Despegue!")