const nombreProducto = `tablet 10 pulgadas`;
let precio = 450.99;
let stock = 25;
const envioGratis = true;

console.log(`Nombre del Producto: ${nombreProducto}`);
console.log(`Precio: ${precio}`);
console.log(`Stock disponible: ${stock}`);
console.log(`Envio Gratis: ${envioGratis}`);