let edadUsuario = 20;
if (edadUsuario >= 18) {
    console.log(`Puedes obtener tu licencia de conducir.`);
} else {
    console.log(`Aún no tienes la edad para obtener la licencia.`);
}