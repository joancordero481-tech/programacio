let colorSemaforo = `amarillo`;
if (colorSemaforo = `verde`);
console.log(`Puede avanzar`);{
} else if(colorSemaforo === `amarillo`) {
    console.log(`Reduzca la velocidad, precaución.`);
} else if (colorSemaforo = `rojo`) {
    console.log(`Debe detenerse.`)
} else if