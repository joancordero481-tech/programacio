//ejercicio 1
const nombreProducto = "Tablet 10 pulgadas";
let precio = 450.99;
let stock = 25;
const envioGratis = true;

console.log(`Nombre del producto:`, nombreProducto);
console.log(`Precio:`, precio);
console.log(`stock disponible:`, stock);
console.log(`¿Envio gratis?:`, envioGratis);




