let edadUsuario = 20;

if (edadUsuario >= 18) {
    console.log(`Puedes obbtener tu licencia de conducir.`);
}
else {
    console.log(`Aun no tienes la edad para obtener la licencia`);
}