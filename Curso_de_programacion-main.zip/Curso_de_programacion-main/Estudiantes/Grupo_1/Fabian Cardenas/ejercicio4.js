let colorSemaforo = "amarillo";

if (colorSemaforo == verde) {
    console.log(`Puedes avanzar`);
}
else if (colorSemaforo == amarillo) {
    console.log(`Reduzca la velocidad, Precaucion`);
}
else if (colorSemaforo == rojo) {
    console.log(`Debe deternerse`);
}
else {
    console.log(`Color no valido`);
}