let diaSemana = 3;

switch (diaSemana) {
    case 1:
        console.log(`Lunes: Lentejas`);
        break;
    case 2:
        console.log(`Martes: Pollo al horno`);
        break;
    case 3:
        console.log(`Miercoles: Pescado a la plancha`);
        break;
    case 4:
        console.log(`Jueves: pasta`);
        break;
    case 5:
        console.log(`Viernes: Paella`);
        break;
    default:
        console.log(`Dia no valida para el menu`);
   }