let cuenta = 10;

while (cuenta > 0) {
    console.log(cuenta);
    cuenta--;
}

console.log(`despegue!`);