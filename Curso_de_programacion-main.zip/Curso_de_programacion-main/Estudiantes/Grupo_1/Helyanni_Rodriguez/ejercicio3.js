let edadusuario = 20;

if (edadusuario >= 18) {
    console.log("Puedes obtener tu licencia de conducir a partir de los 18");
} else {
    console.log("Aun no tienes la edad para obtener tu licencia")
}