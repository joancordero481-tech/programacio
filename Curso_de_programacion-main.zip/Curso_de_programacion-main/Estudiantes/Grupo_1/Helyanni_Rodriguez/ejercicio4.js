let colorSemaforo = "verde";

if (colorSemaforo === "verde") {
    console.log("Puede avanzar");
} else if (colorSemaforo === "amarillo"){
    console.log("Reduzca la velocidad");
} else if (colorSemaforo === "rojo"){
    console.log("Debe detenerse");
} else {
    console.log("Color no valido")
}