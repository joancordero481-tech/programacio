let contador = 10;

while (contador > 0) {
    console.log(contador);
    contador--;
}
console.log("Despegue");