const nombreProducto = "Tablet 10 pulgadas";
let precio = 450.99;
let stock = 25;
const enviosgratis = true;

console.log(`Nombre del producto: ${nombreProducto}`);
console.log(`El Precio del producto es: $${precio}`);
console.log(`Cantidad en stock: ${stock}`);
console.log(`¿Tiene envio gratis?: ${enviosgratis}`);