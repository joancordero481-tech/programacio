let edadUsuario = 19
let tieneentrada = false;

if (edadUsuario >= 18 )