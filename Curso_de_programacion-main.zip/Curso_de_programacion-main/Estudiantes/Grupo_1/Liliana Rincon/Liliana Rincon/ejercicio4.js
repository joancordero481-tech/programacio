let colorsemaforo = "Amarillo";

if (colorsemaforo == "Verde") {
    console.log ("Puedes Avanzar");
} else if (colorsemaforo == "Amarillo")  {
    console.log ("Reduce la velocidad");
}  else if (colorsemaforo == "Rojo")  {
    console.log ("PARAAAAAAAAAAAAAAA, Debes detenerte");
}else {
    console.log ("Color no valido");
}
    