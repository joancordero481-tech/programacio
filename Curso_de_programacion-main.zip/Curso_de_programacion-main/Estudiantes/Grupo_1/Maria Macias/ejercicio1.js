const nombreproducto =`Tablet 10 pulgadas`;

let precio=450.99;
let stock=25;
const enviogratis=true

console.log(`nombre del producto:${nombreproducto}`);
console.log(`precio ${precio}`);
console.log(`cantidad en stock:${stock}unidades`);
console.log(`ènvio gratis: ${enviogratis}`);