const cantidadcomprada=2;
const subtotal=precio*cantidadcomprada;
const impuesto=subtotal* 0.07;
const totalfinal=subtotal* 0.07;
consttotalfinal = subtotal+impuesto;

console.log(`subtotal: $$ {subtotal}`);
console.log(`total final:$${totalfinal}`);