let edadUsuario = 20;
if (edadUsuario >= 18) {
    console.log("puedes obtener tu licencia");
} else {
    console.log("no cumplies con la edad");
} 



