const nombreProducto = "Tablet 10 pulgadas";
let precio = 450.99
let stock = 25
const disponible = true;
const producto = {
    nombre: nombreProducto,
    precioUnitario: precio,
    unidadesEnStock: stock,
    estaDisponible: disponible,};

console.log("Nombre del producto:", producto.nombre);
console.log("precio:", precio);
console.log("disponibilidad:",stock)


