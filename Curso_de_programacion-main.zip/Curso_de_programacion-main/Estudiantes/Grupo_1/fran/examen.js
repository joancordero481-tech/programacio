const nombreProducto = "tablet 10 pulgadas";
let precio = 450.99;
let stock = 25;
const envioGratis = true;

console.log("aqui estan los datos solicitados: ",);
console.log("nombre del producto: ",nombreProducto);
console.log("precio del producto: $",precio);
console.log("cuantos estan en stock: ",stock);
console.log("tiene envio gratis: ",envioGratis);

let cantidad = 2;
let compra = (precio * cantidad);
console.log("gracias por su compra, el precio es: ",compra);

