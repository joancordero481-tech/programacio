let edadUsuario = 20;

if (edadUsuario >= 18) {
    console.log("puedes obtener tu licencia de conducir");

} else {
    console.log("aun no tienes la edad para obtener la licencia");
}
