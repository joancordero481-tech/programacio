let colorSemaforo = "verde";

if (colorSemaforo = "verde") {
    console.log("puede avanzar");
}
else if (colorSemaforo = "amarillo") {
    console.log("amari");
}
else if (colorSemaforo = "rojo") {
    console.log("rojo");
}
else {
    console.log("color no valido");
}