let diaSemana = 3;

switch(diaSemana) {
    case 1:
        console.log("lentejas");
        break;

    case 2:
        console.log("pollo al horno");
        break;
    
    case 3:
        console.log("pescado a la plancha");
        break;
    
    case 4:
        console.log("pasta");
        break;

    case 5:
        console.log("paella");
        break;

}