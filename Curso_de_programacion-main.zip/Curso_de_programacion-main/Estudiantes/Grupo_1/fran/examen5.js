let dos = 2;
let resultado = 1

for (i = 1; resultado <=20; i++ ) {
    let resultado = i * 2;
    console.log("num es: ",resultado);
}
