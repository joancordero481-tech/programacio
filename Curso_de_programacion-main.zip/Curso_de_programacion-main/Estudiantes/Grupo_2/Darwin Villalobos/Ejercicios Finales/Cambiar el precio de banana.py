diccionario_de_precios = {"manzana": 0.5, "banana": 0.3}

diccionario_de_precios ["banana"] = 0.4

print ("El precio de la banana se ha actualizado, ahora el precio de la manzana y la banana es:", diccionario_de_precios)