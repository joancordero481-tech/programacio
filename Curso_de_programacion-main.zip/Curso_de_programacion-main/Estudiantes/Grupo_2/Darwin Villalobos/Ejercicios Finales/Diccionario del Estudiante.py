diccionario = {"Nombre": "Ana",
"edad": "20",
"carrera": "Ingenieria"
}

print("La carrera cursante es: ", diccionario["carrera"])