diccionario_paises = {"pais": "Francia", "pais2": "Italia", "pais3": "España", "capital": "Paris", "capital2": "Roma", "capital3": "Madrid"}

print ("La capital de", diccionario_paises ["pais"], "es", diccionario_paises ["capital"])
print ("La capital de", diccionario_paises ["pais2"], "es", diccionario_paises ["capital2"])
print ("La capital de", diccionario_paises ["pais3"], "es", diccionario_paises ["capital3"])