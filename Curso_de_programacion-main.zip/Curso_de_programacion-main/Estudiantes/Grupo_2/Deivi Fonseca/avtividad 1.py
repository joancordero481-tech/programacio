# tarea
nombre = input ("¿cual es tu nombre?")
edad = input ("¿cuantos años tienes?")
pelicula = input("¿cual es tu pelicula favorita?")
edad_num = int (edad) 
print (f"Hola {nombre}, tienes{edad}, en 10 años tendras{edad_num + 10} tu pelicula favorita es{pelicula}") 
 