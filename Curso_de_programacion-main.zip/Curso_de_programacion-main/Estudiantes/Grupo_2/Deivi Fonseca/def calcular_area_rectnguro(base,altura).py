def calcular_area_rectnguro(base,altura):
    return base * altura
area = calcular_area_rectnguro (4,2)
print(f"el area de un retangulo es: {area}")