print("Conversor de lista de tuplas a diccionario")
lista_de_tuplas = [('nombre', 'Ana'), ('edad', 22), ('ciudad', 'Valencia')]
diccionario = dict(lista_de_tuplas)
print(f"Lista de tuplas original: {lista_de_tuplas}")
print(f"Diccionario resultante: {diccionario}")
