# ejercicio

mi_diccionario = {
     "nombre": "Ana",
     "edad" : "20",
     "carrera" : "ingenieria"
}

print("la carrera es de:", mi_diccionario["carrera"])
