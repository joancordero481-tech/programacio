Nota = int(input("¿Cual es tu nota?"))
if Nota > 17:
    print ("desaprobado")
else:
    print ("aprobado")    