Temperatura = int(input("¿Que temperatura hace hoy en ºc?"))
if Temperatura > 20:
    print ("una chaqueta ligera esta bien")
else:
    print ("Ponte abrigo hace frio")    
