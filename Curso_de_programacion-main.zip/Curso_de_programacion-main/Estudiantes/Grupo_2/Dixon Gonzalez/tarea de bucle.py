contador = 1
while contador < 11:
    print(f"Contador: {contador}")
    contador += 1