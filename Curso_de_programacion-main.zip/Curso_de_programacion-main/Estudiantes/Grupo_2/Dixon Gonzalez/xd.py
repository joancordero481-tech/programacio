input("¿Deberiamos de congelar a los hombres hasta que las mujeres dejen de mentir?")
print ("Si")
input ("ACCESO DENEGADO... TODAS MIENTEN")
