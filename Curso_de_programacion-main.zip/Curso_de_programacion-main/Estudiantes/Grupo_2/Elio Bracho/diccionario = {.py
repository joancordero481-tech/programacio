diccionario = {
    "nombre": "Ana",
    "Edad":20,
    "carrera":"Ingenieria",
    }
print("Profesion:", diccionario["carrera"])