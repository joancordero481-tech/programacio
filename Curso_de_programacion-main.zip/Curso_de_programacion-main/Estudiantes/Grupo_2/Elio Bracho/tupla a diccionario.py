lista = [("Nombre", "Ana"), ("Edad", 23), ("Ciudad", "Maracaibo")]
diccionario = dict(lista)
print(diccionario)