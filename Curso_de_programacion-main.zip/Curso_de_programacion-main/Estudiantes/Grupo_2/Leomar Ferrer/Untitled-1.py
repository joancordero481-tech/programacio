start = input ("estas en un bosque oscuro y encuentras dos ojetos una antorcha o fosforo  y una linterna cual eliges ")
opcion_1 = ("cual escoges: Fosforo o lINTERNA :").lower()
option = input ("si,no")



if start == "fosforo":
 print("has usado fosforo , usas un foforo para enseder la antorcha y te adetrarte mas en el bosque oscuro y a lo lejos vez un oso grizzly! que se esta acercando a ti lenta mente y el fosforo se apagas")
 option_1 = input ("se apaga el fosforo no ties escapatoria y solo puedes hacer tres cosas, esconderte  atra de un arbol , correr o luchar")

if start == "correr":
     option_1= input ("corres los mas rapidos que puede hasta cansarte y el oso esta atras de ti y te enviste para su cena")
option= input ("cundo se apaga la antorcha y vez el oso te escondes en un arbusto sercano y el oso te esta siguiendo el rastro pero no te encontro")
print("ya se a ido el oso por los momentos y sigues tu camino")


 




    


























