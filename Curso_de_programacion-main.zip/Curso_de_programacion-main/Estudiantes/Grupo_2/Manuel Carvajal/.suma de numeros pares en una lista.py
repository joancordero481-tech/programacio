lista=[1,2,3,4,5,6,7,8,9,10]

print("lista original:",lista)

lista1=[1]+[3]+[5]+[7]+[9]

lista2=[2]+[4]+[6]+[8]+[10]

lista3=[2+4+6+8+10]

print("lista impar ",lista1)
print("\n\nlista par ",lista2)
print("\n\nsuma de numeros pares\n\n", lista3,"\n\n")