


alumnos= {
"luis" : {"matematicas", "historia", "biologia"},
"ana" : {"matematicas", "fisica", "quimica"},
"carlos" : {"historia", "arte", "biologia"},
}

materias={"matematicas",
"historia",
"biologia",
"matemaricas",
"fisica",
"quimica",
"historia",
"arte",
"biologia",
}
def union():
    print("\nana y luis comparten matematicas\n")



alumnos["carlos"].add("fisica")
print("\nhay")
print(len(alumnos))
print("alumnos")
print("\nhay")
print(len(materias))
print("materias")


print("\nana y luis comparten matematicas\n")























