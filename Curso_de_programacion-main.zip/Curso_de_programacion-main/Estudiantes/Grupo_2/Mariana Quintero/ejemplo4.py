


# uso de funciones de python
def formular():
    print("area = base * altura" )

    base = int(input("numero 10"))
    altura = int(input("numero 15"))
    
    area = base * altura

formular()
               
    

    