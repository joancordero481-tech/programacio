nota = int(input("¿cual es tu nota?"))
if nota >= 17: 
    print ("aprobado")
else:
    print ("desaprobado")
