temperatura = int(input("¿que temperatura hace hoy en ºc?"))
if temperatura > 20: 
    print ("una chaqueta ligera esta bien")
else:
    print ("ponte un abrigo hace frio")

