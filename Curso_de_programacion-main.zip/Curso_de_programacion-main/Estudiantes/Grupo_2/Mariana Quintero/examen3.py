print("\n--- ejercicio 3 verificador de palindromos---")

palindromos = ["oso radar"]
palabra = input ("ingresa un palidromo:")
print()
palabra = input ("oso y radar son palindromos?").lower()
if palabra.lower()== "si":
    print(f"true {palabra}")
else:
     palabra.lower()== "no"
     print(f"false{palabra}")


     