contador = 1
while contador < 11:
    print(f"contador: {contador}")
    contador += 1

