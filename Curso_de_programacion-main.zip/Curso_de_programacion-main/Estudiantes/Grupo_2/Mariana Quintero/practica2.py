for i in range(10):
    print(f"iteracion {i + 1}")