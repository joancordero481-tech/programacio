#crea un diccionario de estudiante

mi_diccionario = {
    "nombre": "victor",
    "edad": 23,
    "carrera": "panadero",
}

print("carrera:", mi_diccionario["carrera"])

#contar frecuencia de letras

palabra = "banana"

mi_diccionario = {
    "palabra": "banana"
}

print("\npares clave-valor del diccionario:", mi_diccionario.items())


#iterar sobre claves y valores

def funcion_con_kwargs(**kwargs):
